"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.msgHandler = exports.apiHandler = void 0;
const service_config_json_1 = __importDefault(require("./service.config.json"));
const http_1 = require("@onramper/ramp-core/http");
const data_1 = require("./data");
const repo_1 = require("./repo");
const process_1 = require("process");
const app_1 = require("./app");
// API CALLS
// -- Application Gateway V2 calls. When V3 comes we will change here.
const apiHandler = async (event, context) => {
    // CHECK SERVICE GUARDS BEFORE PROCEEDING
    // -- Service guards are specified in service.config.json from the lambda's config layer
    if (service_config_json_1.default.IsServiceDisabled) {
        return http_1.HttpResponse.ServerUnavailable([]);
    }
    // CHECK ENVIRONMENT FOR ERRORS BEFORE PROCEEDING
    // -- We check all configurations, and if they are invalid an array of CoreErrors are returned.
    let envErrors = checkForEnvironmentErrors();
    if (envErrors.length > 0) {
        return http_1.HttpResponse.InternalServerError(envErrors);
    }
    // INITIALIZE APPLICATION
    // -- Create repository instance with parameters from the environment. Because of the 'CHECK SERVICE CONFIGURATIONS'
    // -- we are certain these parameters are not null or empty.
    let repository;
    try {
        repository = new repo_1.CurrenciesRepo(new data_1.ServiceDatabase(
        // -- CURRENCIES_API_TABLE_NAME and CURRENCIES_API_AWS_REGION have already been validated
        //    in checkForEnvironmentErrors() above
        process_1.env.CURRENCIES_API_TABLE_NAME, process_1.env.CURRENCIES_API_AWS_REGION, 
        // -- Because CURRENCIES_API_AWS_ENDPOINT_URL has not been validated yet.
        process_1.env.CURRENCIES_API_AWS_ENDPOINT_URL ? process_1.env.CURRENCIES_API_AWS_ENDPOINT_URL : undefined));
    }
    catch (error) {
        return http_1.HttpResponse.InternalServerError([
            {
                errorId: 1134,
                message: "Could not access the database. ERROR:: " + error
            }
        ]);
    }
    // EXECUTE REQUEST
    // -- Holds the final response from this application.
    let response;
    // -- Routing based on APIGatewayProxyEventV2.routeKey
    switch (event.routeKey) {
        case `GET ${service_config_json_1.default.apiUrlRoot}`:
            response = await (0, app_1.getAllCurrencies)(repository, { countryId: event.queryStringParameters?.country });
            break;
        case `GET ${service_config_json_1.default.apiUrlRoot}/types`:
            response = await (0, app_1.getCurrenciesForType)(repository, "");
            break;
        case `GET ${service_config_json_1.default.apiUrlRoot}/types/{typeName}`:
            response = await (0, app_1.getCurrenciesForType)(repository, event.pathParameters?.typeName);
            break;
        case `GET ${service_config_json_1.default.apiUrlRoot}/{currencyId}`:
            response = await (0, app_1.getCurrency)(repository, event.pathParameters?.currencyId);
            break;
        default:
            response = http_1.HttpResponse.BadRequest([]);
    }
    // Convert the internal CoreHttpResponse object to a native resonse object for the infrastructure.
    return dispatch(response);
};
exports.apiHandler = apiHandler;
// SYSTEM EVENTS
// -- Implementation for Onrampers SQS service
const msgHandler = async (event) => {
    // TODO [ high ]: Integration code goes here ...
};
exports.msgHandler = msgHandler;
function checkForEnvironmentErrors() {
    let errors = [];
    // -- Verify minimum environment variables set.
    if (!process.env.CURRENCIES_API_TABLE_NAME) {
        errors.push({
            errorId: 5021,
            message: `The datasource table name in the environment, is not set. 
                      Please set environment variable "CURRENCIES_API_TABLE_NAME" to a valid table.`
        });
    }
    if (!process.env.CURRENCIES_API_AWS_REGION) {
        errors.push({
            errorId: 5022,
            message: `The datasource region in the environment, is not set. 
                      Please set environment variable "CURRENCIES_API_AWS_REGION" to a valid value.`
        });
    }
    return errors;
}
// APPLICATION BOUNDRY
// -- Converts the service defined 'CoreHttpResponse' to the hosting provider defined 'APIGatewayProxyResultV2'
function dispatch(response) {
    return {
        ...response
    };
}
