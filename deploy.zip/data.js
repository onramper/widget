"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceDatabase = void 0;
const aws_sdk_1 = require("aws-sdk");
const errors_1 = require("@onramper/ramp-core/errors");
// DATABSE CONSTANTS
//=================
const KeySeperator = '#';
const CurrencyTypeIndex = "TypeIndex";
var KeyParts;
(function (KeyParts) {
    KeyParts["CURRENCY_KEY_PREFIX"] = "Currency";
    KeyParts["COUNTRY_KEY_PREFIX"] = "Country";
    KeyParts["ROOT_RECORD"] = "Default";
})(KeyParts || (KeyParts = {}));
// KEY CONVERSIONS
//============
const CurrencyKey = (currencyId) => {
    if (currencyId === "") {
        return "";
    }
    return KeyParts.CURRENCY_KEY_PREFIX.concat(KeySeperator, currencyId.toUpperCase());
};
const CountryKey = (countryId) => {
    return KeyParts.COUNTRY_KEY_PREFIX.concat(KeySeperator, countryId.toUpperCase());
};
const GetIdFromKeyEnd = (currencykey) => {
    if (currencykey === "") {
        return "";
    }
    const keyComponents = currencykey.split(KeySeperator);
    // The Id is at the very end of the key string.
    return keyComponents[keyComponents.length - 1];
};
// DATABASE IMPLEMENTATION
//========================
class ServiceDatabase {
    constructor(tableName, region, endpointUrl) {
        this.tableName = tableName;
        this.db = new aws_sdk_1.DynamoDB.DocumentClient({ region: region, endpoint: endpointUrl });
    }
    async getAllCurrencies() {
        var params = {
            ExpressionAttributeValues: {
                ':s': KeyParts.CURRENCY_KEY_PREFIX,
                ':e': KeyParts.ROOT_RECORD
            },
            //KeyConditionExpression: `Id = :s and begins_with(#i,:e)`,
            ProjectionExpression: 'Id, #n, Networks, Symbol, #t',
            ExpressionAttributeNames: { '#n': 'Name', '#t': 'Type' },
            TableName: this.tableName,
            FilterExpression: "begins_with(Id,:s) and RecordKey = :e",
        };
        let results = await this.db.scan(params).promise();
        // -- Handle the case where result may be an error.
        if (results.$response.error)
            return new errors_1.CoreDatabaseError(this.tableName, results.$response.error);
        return results.Items;
    }
    async getCurrencyForId(id) {
        let params = {
            TableName: this.tableName,
            Key: {
                Id: CurrencyKey(id),
                RecordKey: KeyParts.ROOT_RECORD
            },
            ProjectionExpression: 'Id, #n, Networks, Symbol, #t',
            ExpressionAttributeNames: { '#n': 'Name', '#t': 'Type' },
        };
        let results = await this.db.get(params).promise();
        // -- Handle the case where result may be an error.
        if (results.$response.error) {
            return new errors_1.CoreDatabaseError(this.tableName, results.$response.error);
        }
        return results.Item;
    }
    async getCurrrencyTypes() {
        // Implement a unique list of currency
    }
    async getCurrencyForType(typeName) {
        let params = {
            TableName: this.tableName,
            IndexName: CurrencyTypeIndex,
            KeyConditionExpression: '#t = :t',
            ProjectionExpression: 'Id, #n, Networks, Symbol, #t',
            ExpressionAttributeNames: { '#n': 'Name', '#t': 'Type' },
            ExpressionAttributeValues: { ':t': typeName, ':c': KeyParts.CURRENCY_KEY_PREFIX },
            FilterExpression: 'begins_with(Id,:c) and #t = :t'
        };
        let results = await this.db.scan(params).promise();
        return results.Items;
    }
    async getCurrenciesForCountry(countryId) {
        let params = {
            TableName: this.tableName,
            Key: {
                Id: CountryKey(countryId),
                RecordKey: KeyParts.ROOT_RECORD
            },
            ProjectionExpression: 'BlackList'
        };
        let results = await this.db.get(params).promise();
        if (results.$response.error) {
            return new errors_1.CoreDatabaseError(this.tableName, results.$response.error);
        }
        // -- If the list is empty or a record does not exist, that means no country restrictions are to be applied.
        if (!results.Item?.BlackList) {
            return this.getAllCurrencies();
        }
        let blacklist = JSON.parse(JSON.stringify(results.Item?.BlackList));
        // This scan operation must be replaced by a cached record.
        let currencyResults = await this.getAllCurrencies();
        let items = currencyResults.filter((element) => {
            return !blacklist.includes(GetIdFromKeyEnd(element.Id));
        });
        return items;
    }
}
exports.ServiceDatabase = ServiceDatabase;
