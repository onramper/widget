"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCurrenciesForType = exports.getCurrency = exports.getAllCurrencies = void 0;
const core_1 = require("./core");
const errors_1 = require("@onramper/ramp-core/errors");
const http_1 = require("@onramper/ramp-core/http");
// CONTROLLERS
async function getAllCurrencies(repo, params) {
    let results = await repo.getAllCurrencies(sanitizeParam(params?.countryId));
    if (results instanceof errors_1.CoreDatabaseError) {
        return http_1.HttpResponse.InternalServerError([results]);
    }
    return http_1.HttpResponse.Ok(results);
}
exports.getAllCurrencies = getAllCurrencies;
async function getCurrency(repo, currencyId) {
    // GUARDS
    // -- Handle validation
    let validationsResults = validateCurrencyId(currencyId);
    if (validationsResults.length > 0) {
        return http_1.HttpResponse.BadRequest(validationsResults);
    }
    // EXECUTION
    let results = await repo.getCurrency(currencyId);
    // RESULTS
    // -- Handle Errors
    if (results instanceof core_1.CurrencyNotFoundError) {
        return http_1.HttpResponse.NotFound([results]);
    }
    if (results instanceof errors_1.CoreDatabaseError) {
        return http_1.HttpResponse.InternalServerError([results]);
    }
    // -- Handle Success
    return http_1.HttpResponse.Ok(results);
}
exports.getCurrency = getCurrency;
function validateCurrencyId(currencyId) {
    let errors = [];
    // -- Enter validation criteria here.
    return errors;
}
// -- Removes quotation marks from the query string values.
function sanitizeParam(param) {
    if (param === undefined) {
        return param;
    }
    return param.replace('"', '').replace('"', '');
}
async function getCurrenciesForType(repo, typeName) {
    let results = await repo.getCurrenciesByType(typeName);
    return http_1.HttpResponse.Ok(results);
}
exports.getCurrenciesForType = getCurrenciesForType;
// -- End QUERY PARAMETER OBJECTS
