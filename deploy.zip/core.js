"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CurrencyValidationError = exports.CurrencyNotFoundError = exports.Currency = void 0;
const errors_1 = require("@onramper/ramp-core/errors");
// MODELS
//=======
class Currency {
    constructor(id, name, type, symbol, networks) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.symbol = symbol;
        this.networks = networks;
    }
}
exports.Currency = Currency;
// CUSTOM ERRORS
//==============
class CurrencyNotFoundError extends errors_1.CoreError {
    constructor(currencyId) {
        super(1002, `The currency with Id: ${currencyId} cannot be found. 
            Provide a valid currency Id.`);
    }
}
exports.CurrencyNotFoundError = CurrencyNotFoundError;
class CurrencyValidationError extends errors_1.CoreError {
    constructor(message) {
        super(4000, message);
    }
}
exports.CurrencyValidationError = CurrencyValidationError;
