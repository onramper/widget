"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CurrenciesRepo = void 0;
const core_1 = require("./core");
const errors_1 = require("@onramper/ramp-core/errors");
// APPLICATION REPOSITORY IMPLEMENTATION
class CurrenciesRepo {
    constructor(db) {
        this.db = db;
    }
    async getAllCurrencies(countryId) {
        let results;
        if (countryId) {
            results = await this.db.getCurrenciesForCountry(countryId);
        }
        else {
            results = await this.db.getAllCurrencies();
        }
        if (results instanceof errors_1.CoreError)
            return results;
        // Send the data to the heap
        return results.map((element) => {
            return new core_1.Currency(element.Id, element.Name, element.Type, element.Symbol, element.Networks);
        });
    }
    async getCurrency(currencyId) {
        let currency = await this.db.getCurrencyForId(currencyId);
        if (currency instanceof errors_1.CoreError) {
            return currency;
        }
        if (!currency) {
            return new core_1.CurrencyNotFoundError(currencyId);
        }
        return new core_1.Currency(this.cleanId(currency.Id.toString()), currency.Name, currency.Symbol, currency.Type, currency.Networks);
    }
    async getFiatCurrencies() {
        return this.db.getCurrencyForType('fiat');
    }
    async getCryptoCurrencies() {
        return this.db.getCurrencyForType('crypto');
    }
    async getCurrenciesByType(typeName) {
        return this.db.getCurrencyForType(typeName);
    }
    cleanId(id) {
        return id.slice(id.length - 3);
    }
}
exports.CurrenciesRepo = CurrenciesRepo;
